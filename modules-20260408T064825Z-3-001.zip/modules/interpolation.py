"""
modules/interpolation.py
========================
Builds a continuous AQI pollution surface from discrete station readings
and samples it at road segment midpoints.

Two use cases:
  A. Live surface  — stations DataFrame from openaq_client.fetch_live_aqi()
  B. Historical    — pre-computed road_aqi_output.csv (fallback)

Interpolation methods available:
  - IDW  (Inverse Distance Weighting)  — simple, fast, well understood
  - RBF  (Radial Basis Functions)      — smooth, good for sparse data
  - Kriging (Ordinary)                 — statistically optimal, needs pykrige

The best method is chosen at startup based on LOSO CV results from the
Interpolation_Road_AQI.ipynb notebook. That notebook should be run first
and its result stored in config or passed as an argument.
"""

import math
from typing import Optional

import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.interpolate import RBFInterpolator, LinearNDInterpolator
from scipy.spatial import cKDTree
from shapely.geometry import box

from config import (
    MUMBAI_BBOX,
    PROJECTED_CRS,
    GEOGRAPHIC_CRS,
    GRID_RESOLUTION_M,
    AQI_DISPLAY_MAX,
)

# Optional Kriging import — app works without pykrige, just skips that method
try:
    from pykrige.ok import OrdinaryKriging
    KRIGING_AVAILABLE = True
except ImportError:
    KRIGING_AVAILABLE = False


# ══════════════════════════════════════════════════════════════════════════════
# COORDINATE UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

def latlon_to_utm(lats: np.ndarray, lons: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Convert arrays of lat/lon (WGS84) to UTM Zone 43N (EPSG:32643) coordinates.

    We do this via a temporary GeoDataFrame rather than calling pyproj directly,
    so the projection is guaranteed to match everything else in the pipeline
    that uses geopandas.
    """
    gdf = gpd.GeoDataFrame(
        geometry=gpd.points_from_xy(lons, lats),
        crs=GEOGRAPHIC_CRS
    ).to_crs(PROJECTED_CRS)
    return gdf.geometry.x.values, gdf.geometry.y.values


def build_mumbai_grid() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build a regular UTM grid over the Mumbai bounding box.

    Returns
    -------
    xx, yy        : 2D meshgrid arrays (UTM eastings/northings)
    grid_points   : (N, 2) array of all grid point coordinates

    Grid resolution is set by GRID_RESOLUTION_M in config.py.
    A 200m grid over Mumbai gives ~25,000 points — fast to interpolate
    but fine enough for road-level estimation.
    """
    # Convert bbox corners to UTM
    bbox_gdf = gpd.GeoDataFrame(
        geometry=[box(MUMBAI_BBOX["west"], MUMBAI_BBOX["south"],
                      MUMBAI_BBOX["east"], MUMBAI_BBOX["north"])],
        crs=GEOGRAPHIC_CRS
    ).to_crs(PROJECTED_CRS)

    x_min, y_min, x_max, y_max = bbox_gdf.geometry[0].bounds

    grid_x = np.arange(x_min, x_max, GRID_RESOLUTION_M)
    grid_y = np.arange(y_min, y_max, GRID_RESOLUTION_M)
    xx, yy = np.meshgrid(grid_x, grid_y)
    grid_points = np.column_stack([xx.ravel(), yy.ravel()])

    return xx, yy, grid_points


# ══════════════════════════════════════════════════════════════════════════════
# INTERPOLATION METHODS
# ══════════════════════════════════════════════════════════════════════════════

def idw_interpolate(
    station_pts: np.ndarray,
    station_vals: np.ndarray,
    query_pts: np.ndarray,
    power: float = 2.0,
    eps: float = 1e-10,
) -> np.ndarray:
    """
    Inverse Distance Weighting interpolation.

    Assigns each query point a weighted average of all station values,
    where the weight of station i is 1 / distance_i^power.

    A higher power makes the surface more local (sharp transitions near
    stations). power=2 is standard for environmental data.

    Parameters
    ----------
    station_pts  : (N, 2) UTM coordinates of stations
    station_vals : (N,) AQI values at stations
    query_pts    : (M, 2) UTM coordinates to interpolate at
    power        : distance-decay exponent (default 2)
    eps          : small value to prevent division-by-zero at exact station locations
    """
    tree = cKDTree(station_pts)
    # Query all stations for every point (k=N means use all stations)
    dists, idxs = tree.query(query_pts, k=len(station_pts))
    dists       = np.maximum(dists, eps)
    weights     = 1.0 / (dists ** power)
    result      = (weights * station_vals[idxs]).sum(axis=1) / weights.sum(axis=1)
    return np.clip(result, 0, AQI_DISPLAY_MAX)


def rbf_interpolate(
    station_pts: np.ndarray,
    station_vals: np.ndarray,
    query_pts: np.ndarray,
    kernel: str = "thin_plate_spline",
    smoothing: float = 0.0,
) -> np.ndarray:
    """
    Radial Basis Function interpolation.

    Fits a smooth global function through the station data points.
    'thin_plate_spline' is the standard choice for spatial data — it
    minimises the bending energy of the surface, producing a physically
    plausible smooth field.

    smoothing=0 means exact interpolation (surface passes exactly through
    each station value). smoothing>0 allows the surface to deviate from
    the observations, acting as regularisation — useful when stations have
    measurement noise.

    Coordinates are normalised before fitting for numerical stability.

    Parameters
    ----------
    kernel   : 'thin_plate_spline' | 'multiquadric' | 'linear' | 'cubic'
    smoothing: regularisation parameter (0 = exact interpolation)
    """
    # Normalise coordinates to unit scale for numerical stability
    scale   = station_pts.std(axis=0).mean() or 1.0
    pts_n   = station_pts / scale
    qry_n   = query_pts   / scale

    rbf    = RBFInterpolator(pts_n, station_vals, kernel=kernel, smoothing=smoothing)
    result = rbf(qry_n)
    return np.clip(result, 0, AQI_DISPLAY_MAX)


def kriging_interpolate(
    station_pts: np.ndarray,
    station_vals: np.ndarray,
    query_pts: np.ndarray,
    variogram_model: str = "spherical",
) -> np.ndarray:
    """
    Ordinary Kriging interpolation (requires pykrige).

    Kriging is the geostatistically optimal interpolator when the spatial
    covariance structure (variogram) of the field is known or can be
    estimated from the data. It weights stations by their spatial correlation
    rather than just distance.

    The 'spherical' variogram model is standard for environmental variables —
    it assumes correlation drops to zero at a finite range (the range of
    influence), which is physically reasonable for urban pollution.

    Falls back to IDW if pykrige is not installed.

    Parameters
    ----------
    variogram_model: 'spherical' | 'exponential' | 'gaussian' | 'linear'
    """
    if not KRIGING_AVAILABLE:
        return idw_interpolate(station_pts, station_vals, query_pts)

    ok     = OrdinaryKriging(
        station_pts[:, 0], station_pts[:, 1], station_vals,
        variogram_model=variogram_model,
        verbose=False, enable_plotting=False
    )
    z, _   = ok.execute("points", query_pts[:, 0], query_pts[:, 1])
    return np.clip(np.array(z), 0, AQI_DISPLAY_MAX)


# Map of method names to callable functions (used by the app's method selector)
INTERPOLATION_METHODS = {
    "IDW (power=2)":            lambda pts, vals, qry: idw_interpolate(pts, vals, qry, power=2),
    "IDW (power=1)":            lambda pts, vals, qry: idw_interpolate(pts, vals, qry, power=1),
    "RBF (thin plate spline)":  lambda pts, vals, qry: rbf_interpolate(pts, vals, qry, "thin_plate_spline"),
    "RBF (multiquadric)":       lambda pts, vals, qry: rbf_interpolate(pts, vals, qry, "multiquadric"),
    "Kriging (spherical)":      lambda pts, vals, qry: kriging_interpolate(pts, vals, qry, "spherical"),
}


# ══════════════════════════════════════════════════════════════════════════════
# LEAVE-ONE-STATION-OUT CROSS-VALIDATION (LOSO CV)
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_model(
    stations_df: pd.DataFrame,
    method_name: str = "IDW (power=2)",
) -> dict:
    """
    Evaluate an interpolation method using Leave-One-Station-Out CV (LOSO CV).

    Algorithm
    ---------
    For each station i with a valid AQI reading:
      1. Hold out station i (the "test" station)
      2. Fit the interpolator using all other stations as training data
      3. Predict AQI at station i's location
      4. Record: predicted value, actual value, absolute error

    Aggregate metrics over all held-out stations:
      - RMSE  = sqrt( mean( (pred - actual)² ) )  — penalises large errors more
      - MAE   = mean( |pred - actual| )            — average absolute error
      - Bias  = mean( pred - actual )              — systematic over/under-estimation
      - R²    = 1 - SS_res / SS_tot               — variance explained (1.0 = perfect)

    Parameters
    ----------
    stations_df : DataFrame with (lat, lon, aqi) columns — from fetch_live_aqi()
                  or the historical stations CSV.
    method_name : key into INTERPOLATION_METHODS

    Returns
    -------
    dict with keys:
        method        : method name
        rmse          : Root Mean Squared Error (AQI units)
        mae           : Mean Absolute Error (AQI units)
        bias          : Mean signed error (pred − actual)
        r2            : R-squared coefficient
        n_stations    : number of stations used in CV
        per_station   : list of dicts {station_name, lat, lon, actual, predicted, error}
        error         : error message string if evaluation failed, else None
    """
    interp_fn = INTERPOLATION_METHODS.get(method_name)
    if interp_fn is None:
        return {"error": f"Unknown method: {method_name}", "method": method_name}

    # Only use stations with valid AQI readings
    valid = stations_df.dropna(subset=["aqi"]).reset_index(drop=True)
    n = len(valid)

    if n < 3:
        return {
            "error": (
                f"Need at least 3 stations with valid AQI for LOSO CV "
                f"(got {n}). Load live data or check your OpenAQ key."
            ),
            "method": method_name,
            "n_stations": n,
        }

    # Convert all station lat/lon to UTM once (avoids repeated projection)
    x_utm, y_utm = latlon_to_utm(valid["lat"].values, valid["lon"].values)
    all_pts  = np.column_stack([x_utm, y_utm])   # shape (n, 2)
    all_vals = valid["aqi"].values.astype(float)  # shape (n,)

    per_station = []
    actuals     = []
    predictions = []

    for i in range(n):
        # Mask: everything except station i
        mask      = np.ones(n, dtype=bool)
        mask[i]   = False

        train_pts  = all_pts[mask]    # (n-1, 2) — the "known" stations
        train_vals = all_vals[mask]   # (n-1,)
        test_pt    = all_pts[[i]]     # (1, 2)   — held-out station

        # Need at least 2 training points for any interpolation to make sense
        if train_pts.shape[0] < 2:
            continue

        try:
            pred_arr = interp_fn(train_pts, train_vals, test_pt)
            predicted = float(pred_arr[0])
        except Exception:
            # If this fold fails (e.g. singular matrix in Kriging), skip it
            continue

        actual = float(all_vals[i])
        error  = predicted - actual

        actuals.append(actual)
        predictions.append(predicted)

        per_station.append({
            "station_name": str(valid.iloc[i].get("station_name", f"Station {i}")),
            "lat":          float(valid.iloc[i]["lat"]),
            "lon":          float(valid.iloc[i]["lon"]),
            "actual":       round(actual, 1),
            "predicted":    round(predicted, 1),
            "error":        round(error, 1),      # signed: + means over-prediction
            "abs_error":    round(abs(error), 1),
        })

    if len(actuals) < 2:
        return {
            "error": "Too many CV folds failed. Check station data quality.",
            "method": method_name,
            "n_stations": n,
        }

    actuals     = np.array(actuals)
    predictions = np.array(predictions)
    residuals   = predictions - actuals

    rmse = float(np.sqrt(np.mean(residuals ** 2)))
    mae  = float(np.mean(np.abs(residuals)))
    bias = float(np.mean(residuals))

    ss_res = float(np.sum(residuals ** 2))
    ss_tot = float(np.sum((actuals - actuals.mean()) ** 2))
    r2     = float(1 - ss_res / ss_tot) if ss_tot > 1e-9 else float("nan")

    return {
        "method":      method_name,
        "rmse":        round(rmse, 2),
        "mae":         round(mae, 2),
        "bias":        round(bias, 2),
        "r2":          round(r2, 3),
        "n_stations":  n,
        "n_folds":     len(actuals),
        "per_station": per_station,
        "error":       None,
    }


# ══════════════════════════════════════════════════════════════════════════════
# SURFACE BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_live_surface(
    stations_df: pd.DataFrame,
    method_name: str = "IDW (power=2)",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build a continuous AQI surface from live station readings.

    Converts station lat/lon to UTM, builds a grid over Mumbai,
    runs the chosen interpolation method, and returns the 2D surface.

    Parameters
    ----------
    stations_df : DataFrame with (lat, lon, aqi) columns — from fetch_live_aqi()
    method_name : key into INTERPOLATION_METHODS dict

    Returns
    -------
    xx           : 2D meshgrid of UTM eastings
    yy           : 2D meshgrid of UTM northings
    grid_aqi_2d  : 2D array of interpolated AQI values (same shape as xx/yy)
    """
    # Drop stations with no AQI reading
    valid = stations_df.dropna(subset=["aqi"])
    if len(valid) < 2:
        raise ValueError(
            f"Need at least 2 stations with valid AQI to interpolate "
            f"(got {len(valid)})."
        )

    # Convert to UTM for metric calculations
    x_utm, y_utm = latlon_to_utm(valid["lat"].values, valid["lon"].values)
    station_pts  = np.column_stack([x_utm, y_utm])
    station_vals = valid["aqi"].values.astype(float)

    # Build the Mumbai-wide grid
    xx, yy, grid_pts = build_mumbai_grid()

    # Run interpolation
    interp_fn  = INTERPOLATION_METHODS.get(method_name, INTERPOLATION_METHODS["IDW (power=2)"])
    grid_aqi   = interp_fn(station_pts, station_vals, grid_pts)
    grid_aqi_2d = grid_aqi.reshape(xx.shape)

    return xx, yy, grid_aqi_2d


def sample_surface_at_roads(
    road_geo: pd.DataFrame,
    stations_df: pd.DataFrame,
    method_name: str = "IDW (power=2)",
) -> pd.DataFrame:
    """
    Sample the live AQI surface at every road segment midpoint.

    For each road segment midpoint, find the interpolated AQI value
    from the surface built using the live station readings.

    This is more direct than building the full raster and then sampling —
    we interpolate directly at the road midpoint coordinates.

    Parameters
    ----------
    road_geo    : DataFrame(edge_idx, mid_lat, mid_lon) — road segment midpoints
    stations_df : DataFrame(lat, lon, aqi) — live station readings
    method_name : interpolation method to use

    Returns
    -------
    DataFrame with (edge_idx, mid_lat, mid_lon, aqi_pred)
    """
    valid = stations_df.dropna(subset=["aqi"])
    if len(valid) < 2:
        raise ValueError("Insufficient stations for road surface sampling.")

    # Convert station lat/lon to UTM
    sx, sy       = latlon_to_utm(valid["lat"].values, valid["lon"].values)
    station_pts  = np.column_stack([sx, sy])
    station_vals = valid["aqi"].values.astype(float)

    # Convert road midpoints lat/lon to UTM
    roads_valid = road_geo.dropna(subset=["mid_lat", "mid_lon"]).copy()
    rx, ry      = latlon_to_utm(roads_valid["mid_lat"].values,
                                roads_valid["mid_lon"].values)
    road_pts    = np.column_stack([rx, ry])

    # Interpolate at every road midpoint
    interp_fn = INTERPOLATION_METHODS.get(method_name, INTERPOLATION_METHODS["IDW (power=2)"])
    aqi_vals  = interp_fn(station_pts, station_vals, road_pts)

    roads_valid = roads_valid.copy()
    roads_valid["aqi_pred"] = aqi_vals

    return roads_valid[["edge_idx", "mid_lat", "mid_lon", "aqi_pred"]]


# ══════════════════════════════════════════════════════════════════════════════
# ROAD GEOMETRY — KD-TREE FOR FAST LOOKUP
# ══════════════════════════════════════════════════════════════════════════════

def build_road_kdtree(road_aqi_df: pd.DataFrame) -> tuple[pd.DataFrame, cKDTree]:
    """
    Build a KD-tree from road segment midpoint coordinates.

    Used to quickly find the nearest road segment for any arbitrary
    coordinate (e.g. a waypoint along a routing polyline).

    Parameters
    ----------
    road_aqi_df : DataFrame(edge_idx, mid_lat, mid_lon, aqi_pred)

    Returns
    -------
    road_geo  : cleaned road geometry DataFrame
    kd_tree   : cKDTree built from (mid_lat, mid_lon) coordinates
    """
    road_geo = road_aqi_df.dropna(subset=["mid_lat", "mid_lon"]).copy()
    coords   = road_geo[["mid_lat", "mid_lon"]].values
    kd_tree  = cKDTree(coords)
    return road_geo, kd_tree
