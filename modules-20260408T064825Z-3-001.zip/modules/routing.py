"""
modules/routing.py
==================
Handles route fetching from OpenRouteService (ORS) and computes
pollution exposure along each returned route.

Two core responsibilities:
  1. fetch_routes()     — call ORS API, return raw route geometries + metadata
  2. compute_exposure() — for each route, calculate distance-weighted mean AQI

Fastest vs Cleanest:
  ORS returns routes ordered by travel time (fastest first).
  The "cleanest" route is the one with the lowest distance-weighted mean AQI
  among all returned alternatives. This is determined after computing
  exposure for all routes, not by the routing algorithm itself.

Exposure metrics:
  - mean_aqi   = Σ(AQI_i × length_i) / Σ(length_i)
    The average pollution level experienced along the route.
    Lower is better for brief exposure (e.g. cycling).

  - total_dose = Σ(AQI_i × length_i)  in units of µg/m³·m
    Proportional to total pollutant intake.
    A long clean route can have lower mean_aqi but higher total_dose
    than a short polluted one. Use this for health impact comparison.
"""

import math
from typing import Optional

import numpy as np
import pandas as pd
import requests
from scipy.spatial import cKDTree

from config import (
    ORS_BASE_URL,
    ORS_TIMEOUT_S,
    ORS_N_ALTERNATIVES,
)


# ══════════════════════════════════════════════════════════════════════════════
# GEOMETRY UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Compute the great-circle distance in metres between two lat/lon points.

    Uses the haversine formula — accurate to within ~0.3% for distances
    up to several hundred km. More than sufficient for intra-city routing.
    """
    R = 6_371_000  # Earth's mean radius in metres
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = (math.sin(dphi / 2) ** 2
         + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def format_duration(seconds: float) -> str:
    """Format a duration in seconds to a human-readable string e.g. '23 min'."""
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}h {m}min"
    if m >= 5:
        return f"{m} min"
    return f"{m}min {s}s"


def format_distance(metres: float) -> str:
    """Format a distance in metres to a human-readable string e.g. '4.2 km'."""
    if metres >= 1000:
        return f"{metres / 1000:.1f} km"
    return f"{metres:.0f} m"


# ══════════════════════════════════════════════════════════════════════════════
# OPENROUTESERVICE API
# ══════════════════════════════════════════════════════════════════════════════

def fetch_routes(
    origin_ll: tuple[float, float],
    dest_ll: tuple[float, float],
    ors_profile: str,
    api_key: str,
    n_alternatives: int = ORS_N_ALTERNATIVES,
) -> list[dict]:
    """
    Fetch driving/walking/cycling routes from OpenRouteService v2.

    Uses the GeoJSON directions endpoint which returns full geometry
    (all waypoints, not just start/end).

    Alternative routes are requested using ORS's built-in algorithm:
      - weight_factor: alternatives can be up to 1.6× longer than the fastest
      - share_factor:  alternatives share at most 60% of geometry with fastest
    These values ensure meaningfully different paths, not minor deviations.

    Parameters
    ----------
    origin_ll      : (lat, lon) of origin
    dest_ll        : (lat, lon) of destination
    ors_profile    : ORS profile string e.g. 'driving-car', 'foot-walking'
    api_key        : OpenRouteService API key
    n_alternatives : number of alternatives beyond the fastest (max 2)

    Returns
    -------
    List of route dicts, each containing:
        geometry   : list of [lon, lat] waypoints (ORS returns lon first)
        duration_s : travel time in seconds
        distance_m : route length in metres
        duration_str, distance_str : formatted strings for display

    Returns [] on any error (caller handles gracefully).
    """
    url = f"{ORS_BASE_URL}/{ors_profile}/geojson"

    # ORS expects coordinates as [lon, lat] arrays
    payload = {
        "coordinates": [
            [origin_ll[1], origin_ll[0]],
            [dest_ll[1],   dest_ll[0]],
        ],
        "alternative_routes": {
            "target_count": n_alternatives + 1,
            "weight_factor": 1.6,
            "share_factor":  0.6,
        },
        "instructions":      False,   # We don't need turn-by-turn text
        "geometry_simplify": False,   # Keep full geometry for accurate exposure
    }

    headers = {
        "Authorization": api_key,
        "Content-Type":  "application/json",
    }

    try:
        resp = requests.post(
            url, json=payload, headers=headers, timeout=ORS_TIMEOUT_S
        )
        resp.raise_for_status()
        data = resp.json()

    except requests.exceptions.HTTPError as e:
        status = e.response.status_code
        if status == 401:
            raise ValueError("Invalid ORS API key.")
        if status == 403:
            raise ValueError("ORS API key does not have directions access.")
        if status == 429:
            raise RuntimeError("ORS rate limit exceeded. Try again in a minute.")
        raise RuntimeError(
            f"ORS API error {status}: {e.response.text[:200]}"
        )
    except requests.exceptions.Timeout:
        raise RuntimeError("ORS request timed out. Check your connection.")
    except Exception as e:
        raise RuntimeError(f"Routing failed: {e}")

    routes = []
    for feat in data.get("features", []):
        geom  = feat.get("geometry", {}).get("coordinates", [])
        segs  = feat.get("properties", {}).get("segments", [{}])
        if not geom:
            continue

        dur_s  = segs[0].get("duration", 0) if segs else 0
        dist_m = segs[0].get("distance", 0) if segs else 0

        routes.append({
            "geometry":     geom,         # list of [lon, lat]
            "duration_s":   dur_s,
            "distance_m":   dist_m,
            "duration_str": format_duration(dur_s),
            "distance_str": format_distance(dist_m),
            # Exposure fields filled in by compute_exposure()
            "mean_aqi":   float("nan"),
            "total_dose": float("nan"),
            "seg_aqis":   [],
            "is_fastest":  False,
            "is_cleanest": False,
        })

    return routes


# ══════════════════════════════════════════════════════════════════════════════
# POLLUTION EXPOSURE CALCULATION
# ══════════════════════════════════════════════════════════════════════════════

def compute_exposure(
    route: dict,
    road_geo: pd.DataFrame,
    kd_tree: cKDTree,
    aqi_surface_df: pd.DataFrame,
) -> dict:
    """
    Calculate pollution exposure for a single route.

    Algorithm:
      For each consecutive pair of waypoints in the route geometry:
        1. Compute the physical length of that segment (haversine, metres)
        2. Find the nearest road segment in our AQI dataset via KD-tree
        3. Assign that segment's AQI value

      Aggregate:
        mean_aqi   = Σ(AQI_i × len_i) / Σ(len_i)  — distance-weighted average
        total_dose = Σ(AQI_i × len_i)              — total pollutant intake proxy

    The KD-tree lookup maps each route waypoint to the nearest monitored
    road segment. Segments further than 500m from any monitored road are
    skipped (avoids erroneous assignments to segments in the sea etc.).

    Parameters
    ----------
    route          : route dict from fetch_routes()
    road_geo       : DataFrame(edge_idx, mid_lat, mid_lon)
    kd_tree        : cKDTree on road_geo (mid_lat, mid_lon) coordinates
    aqi_surface_df : DataFrame(edge_idx, aqi_pred) for the current time

    Returns
    -------
    The input route dict updated with:
        mean_aqi, total_dose, seg_aqis (list of per-segment AQI values)
    """
    MAX_SNAP_DIST_M = 500   # Ignore road segments further than this

    aqi_lookup = dict(zip(aqi_surface_df["edge_idx"], aqi_surface_df["aqi_pred"]))
    edge_ids   = road_geo["edge_idx"].values

    total_weighted = 0.0
    total_length   = 0.0
    seg_aqis       = []

    coords = route["geometry"]   # list of [lon, lat]

    for i in range(len(coords) - 1):
        lon1, lat1 = coords[i]
        lon2, lat2 = coords[i + 1]

        seg_len = haversine(lat1, lon1, lat2, lon2)
        if seg_len < 0.5:
            continue   # Skip near-zero segments (duplicate waypoints)

        mid_lat = (lat1 + lat2) / 2
        mid_lon = (lon1 + lon2) / 2

        # Find the nearest road segment in the AQI dataset
        dist_deg, idx = kd_tree.query([mid_lat, mid_lon], k=1)

        # Convert approximate degree distance to metres for the snapping check
        # ~111,000 m per degree at Mumbai's latitude
        dist_m = dist_deg * 111_000
        if dist_m > MAX_SNAP_DIST_M:
            continue   # Too far from any monitored road — skip this segment

        seg_aqi = aqi_lookup.get(edge_ids[idx])
        if seg_aqi is None or math.isnan(seg_aqi):
            continue

        total_weighted += seg_aqi * seg_len
        total_length   += seg_len
        seg_aqis.append(float(seg_aqi))

    route["mean_aqi"]   = total_weighted / total_length if total_length > 0 else float("nan")
    route["total_dose"] = total_weighted   # µg/m³·m
    route["seg_aqis"]   = seg_aqis

    return route


def tag_fastest_and_cleanest(routes: list[dict]) -> list[dict]:
    """
    Mark which route is fastest and which is cleanest.

    Fastest  = minimum duration_s
    Cleanest = minimum mean_aqi (among routes with valid AQI data)

    If no route has valid AQI data, cleanest defaults to fastest.

    Modifies routes in-place and also returns the list.
    """
    if not routes:
        return routes

    # Fastest
    fastest_idx = min(range(len(routes)), key=lambda i: routes[i]["duration_s"])
    routes[fastest_idx]["is_fastest"] = True

    # Cleanest
    valid_aqi = [
        i for i, r in enumerate(routes)
        if not math.isnan(r.get("mean_aqi", float("nan")))
    ]
    if valid_aqi:
        cleanest_idx = min(valid_aqi, key=lambda i: routes[i]["mean_aqi"])
    else:
        cleanest_idx = fastest_idx

    routes[cleanest_idx]["is_cleanest"] = True

    return routes
