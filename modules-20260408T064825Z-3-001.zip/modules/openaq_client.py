"""
modules/openaq_client.py
========================
Handles all communication with the OpenAQ v3 API and AQI computation.

Key v3 changes from v1/v2:
  - Authentication: X-API-Key header (not query param)
  - No bulk /latest endpoint — must call /v3/locations/{id}/latest per station
  - /locations/{id}/latest response contains sensorsId + value,
    NOT parameter name. Parameter names come from /v3/locations sensors list.
    You MUST build a sensor_id → pollutant map from the locations call first.
"""

import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import Optional

import pandas as pd
import numpy as np
import requests

from config import (
    OPENAQ_BASE_URL,
    OPENAQ_TIMEOUT_S,
    OPENAQ_PAGE_LIMIT,
    MUMBAI_BBOX,
    CPCB_BREAKPOINTS,
    AQI_CATEGORIES,
    HISTORICAL_MONTH_MAP,
    FALLBACK_CSV_PATH,
    MIN_LIVE_STATIONS,
    CACHE_TTL_MINUTES,
)

# OpenAQ parameter name → CPCB pollutant code
# OpenAQ uses "pm2.5" not "pm25", "no2" matches, etc.
PARAM_MAP = {
    "pm25":  "pm25",
    "pm2.5": "pm25",
    "pm10":  "pm10",
    "no2":   "no2",
    "co":    "co",
    "so2":   "so2",
}


# ══════════════════════════════════════════════════════════════════════════════
# AQI CALCULATION
# ══════════════════════════════════════════════════════════════════════════════

def sub_index(concentration: float, pollutant: str) -> Optional[float]:
    """Compute CPCB sub-index for a single pollutant using piecewise linear formula."""
    if concentration is None or math.isnan(concentration) or concentration < 0:
        return None
    for (c_lo, c_hi, i_lo, i_hi) in CPCB_BREAKPOINTS.get(pollutant, []):
        if c_lo <= concentration <= c_hi:
            return ((i_hi - i_lo) / (c_hi - c_lo)) * (concentration - c_lo) + i_lo
    bp = CPCB_BREAKPOINTS.get(pollutant, [])
    return 500.0 if bp and concentration > bp[-1][1] else None


def sanitize_pollutant_readings(readings: dict) -> dict:
    """
    Apply unit conversions and outlier rejection before computing AQI sub-indices.

    Unit mismatch: OpenAQ v3 reports CO in µg/m³, but CPCB AQI breakpoints use mg/m³.
    Detection heuristic: legitimate urban CO in mg/m³ tops out at ~20 mg/m³ even in
    severely polluted conditions. Any reading > 50 (the max CPCB breakpoint in mg/m³)
    is physically impossible in mg/m³ and indicates the value is actually in µg/m³.
    Division by 1000 converts µg/m³ → mg/m³.

    PM sanity check: PM2.5 > 1000 µg/m³ or PM10 > 1500 µg/m³ are sensor errors —
    the highest recorded values in Indian cities top out around 700–900 µg/m³.
    """
    sanitized = {}
    for code, value in readings.items():
        if value is None or (isinstance(value, float) and math.isnan(value)):
            sanitized[code] = None
            continue

        if code == "co":
            # Convert µg/m³ → mg/m³ when the value is clearly in µg/m³
            # (anything > 50 is impossible in mg/m³; typical µg/m³ range: 200–4000)
            sanitized[code] = value / 1000 if value > 50 else value

        elif code == "pm25" and value > 1000:
            # Reject physically implausible PM2.5 readings (sensor error)
            sanitized[code] = None

        elif code == "pm10" and value > 1500:
            # Reject physically implausible PM10 readings (sensor error)
            sanitized[code] = None

        elif code == "no2" and value > 2000:
            # NO2 > 2000 µg/m³ is a sensor error; CPCB max breakpoint is 800
            sanitized[code] = None

        else:
            sanitized[code] = value

    return sanitized


def compute_station_aqi(pollutant_values: dict) -> Optional[float]:
    """
    Compute CPCB AQI = max(sub-indices).
    CPCB requires >= 3 valid sub-indices for a proper AQI.
    Returns best-effort max if 1 or 2 available.
    """
    sub_indices = [
        si for pol, conc in pollutant_values.items()
        if (si := sub_index(conc, pol)) is not None
    ]
    return max(sub_indices) if sub_indices else None


def aqi_category(value: Optional[float]) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "Unknown"
    for threshold, name in AQI_CATEGORIES:
        if value <= threshold:
            return name
    return "Severe"


# ══════════════════════════════════════════════════════════════════════════════
# OpenAQ v3 API CLIENT
# ══════════════════════════════════════════════════════════════════════════════

def _build_headers(api_key: str) -> dict:
    """v3 uses X-API-Key header authentication."""
    return {
        "X-API-Key":    api_key,
        "Accept":       "application/json",
        "Content-Type": "application/json",
    }


def fetch_mumbai_locations(api_key: str) -> tuple[list[dict], dict, dict]:
    """
    Fetch all active monitoring locations within Mumbai bounding box.

    Builds two lookup maps:
      sensor_map          : {sensor_id (int) → cpcb_pollutant_code (str)}
        Used to decode /latest responses which only return sensorsId.

      location_sensor_map : {location_id (int) → {sensor_id (int) → cpcb_code (str)}}
        Used by the averaged fetcher so each location only queries its own sensors,
        avoiding spurious cross-location API calls.

    Returns
    -------
    locations           : list of location dicts from OpenAQ
    sensor_map          : global {sensor_id: cpcb_code}
    location_sensor_map : per-location {location_id: {sensor_id: cpcb_code}}
    """
    url   = f"{OPENAQ_BASE_URL}/locations"
    bbox  = (f"{MUMBAI_BBOX['west']},{MUMBAI_BBOX['south']},"
             f"{MUMBAI_BBOX['east']},{MUMBAI_BBOX['north']}")
    params = {"bbox": bbox, "limit": OPENAQ_PAGE_LIMIT, "page": 1}

    try:
        resp = requests.get(
            url, headers=_build_headers(api_key),
            params=params, timeout=OPENAQ_TIMEOUT_S
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.HTTPError as e:
        status = e.response.status_code
        if status == 401:
            raise ValueError("Invalid OpenAQ API key. Get a free key at explore.openaq.org/register.")
        if status == 429:
            raise RuntimeError("OpenAQ rate limit exceeded. Wait 60 seconds and try again.")
        raise RuntimeError(f"OpenAQ locations fetch failed: {status} — {e.response.text[:200]}")
    except requests.exceptions.Timeout:
        raise RuntimeError("OpenAQ locations request timed out.")
    except Exception as e:
        raise RuntimeError(f"OpenAQ locations error: {e}")

    locations = data.get("results", [])

    sensor_map: dict[int, str] = {}
    location_sensor_map: dict[int, dict[int, str]] = {}

    for loc in locations:
        loc_id = loc["id"]
        loc_sensors: dict[int, str] = {}
        for sensor in loc.get("sensors", []):
            sensor_id  = sensor.get("id")
            param_name = sensor.get("parameter", {}).get("name", "").lower()
            cpcb_code  = PARAM_MAP.get(param_name)
            if sensor_id is not None and cpcb_code is not None:
                sensor_map[sensor_id]      = cpcb_code
                loc_sensors[sensor_id]     = cpcb_code
        location_sensor_map[loc_id] = loc_sensors

    return locations, sensor_map, location_sensor_map


# CPCB-mandated averaging windows per pollutant (in hours).
# PM2.5 and PM10 require 24-hour averages; CO requires 8-hour; NO2/SO2 use 1-hour.
# Source: CPCB National AQI (2014), Section 3 — "Averaging Period".
# Applying the breakpoint table to a shorter window (e.g. a 1-hour spike)
# produces inflated sub-indices that do NOT match official CPCB readings.
AVERAGING_HOURS: dict[str, int] = {
    "pm25": 24,
    "pm10": 24,
    "co":    8,
    "no2":   1,
    "so2":   1,
}


def _fetch_sensor_average(
    api_key: str,
    sensor_id: int,
    cpcb_code: str,
    now_utc: datetime,
) -> Optional[float]:
    """
    Fetch the time-averaged concentration for one sensor over the CPCB window.

    Endpoint: GET /v3/sensors/{sensor_id}/hours
      Returns hourly aggregated values for the sensor.
      We request the last N hours (N = AVERAGING_HOURS[cpcb_code]) and
      compute the mean of all returned hourly values.

    Why hourly aggregates and not raw measurements?
      Raw measurements (/measurements) can include sub-hourly data at varying
      cadences — averaging them directly would over-weight high-frequency sensors.
      The /hours endpoint already gives one mean value per clock hour, so a
      simple mean of the returned rows gives us the correct time-average.

    Returns the averaged concentration, or None if insufficient data.
    """
    window_h = AVERAGING_HOURS.get(cpcb_code, 1)
    date_to   = now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    date_from = (now_utc - timedelta(hours=window_h)).strftime("%Y-%m-%dT%H:%M:%SZ")

    url = f"{OPENAQ_BASE_URL}/sensors/{sensor_id}/hours"
    try:
        resp = requests.get(
            url,
            headers=_build_headers(api_key),
            params={
                "datetime_from": date_from,
                "datetime_to":   date_to,
                "limit":         window_h + 2,   # small buffer for clock edges
            },
            timeout=OPENAQ_TIMEOUT_S,
        )
        resp.raise_for_status()
        results = resp.json().get("results", [])
    except Exception:
        return None

    # Each result has a "value" field (the hourly mean concentration).
    # We need at least 50% coverage to consider the average reliable —
    # e.g. for a 24-hour PM2.5 average, at least 12 hourly readings.
    values = []
    for rec in results:
        # v3 /hours response: {"value": 45.2, "period": {...}, ...}
        raw = rec.get("value")
        if raw is None:
            # Some responses nest it under summary
            raw = rec.get("summary", {}).get("avg")
        if raw is None:
            continue
        try:
            v = float(raw)
        except (TypeError, ValueError):
            continue
        if not math.isnan(v) and v >= 0:
            values.append(v)

    min_coverage = max(1, window_h // 2)   # 50% of the window must be present
    if len(values) < min_coverage:
        return None   # Not enough data for a reliable average

    return float(np.mean(values))


def _fetch_one_location_averaged(
    api_key: str,
    location_id: int,
    sensor_map: dict[int, str],
    now_utc: datetime,
) -> tuple[int, dict]:
    """
    Fetch CPCB-correct time-averaged concentrations for one location.

    For each sensor at this location:
      - PM2.5, PM10 → 24-hour average via /sensors/{id}/hours
      - CO          →  8-hour average via /sensors/{id}/hours
      - NO2, SO2    →  1-hour average via /sensors/{id}/hours

    This matches the averaging periods mandated by CPCB's AQI standard,
    so the resulting sub-indices and composite AQI align with CPCB's
    official published values rather than snapshot instantaneous readings.

    Falls back to the /latest endpoint for any sensor whose hourly history
    is unavailable (e.g. new stations, data gaps), so we never silently
    drop a station just because one averaging call failed.

    Returns (location_id, {cpcb_code: averaged_concentration}).
    """
    # Identify sensors at this location that we care about
    relevant_sensors: dict[int, str] = {
        sid: code
        for sid, code in sensor_map.items()
        # sensor_map is global across all locations; filter to this location
        # by checking later — we pass all and let the API 404 non-matching ones
    }

    # Build a reverse lookup: cpcb_code → list of sensor_ids for THIS location.
    # We get the per-location sensor list from the sensor_map keys we already have.
    # Since sensor IDs are globally unique across OpenAQ, we just iterate all
    # sensors in sensor_map and try to fetch; the API will return empty results
    # for sensors not belonging to this location.
    # More efficient: build a location→sensors map in fetch_mumbai_locations.
    # For now, we filter using the location's own sensors list stored separately.
    # → This function receives only the sensor_ids that belong to this location
    #   (filtered by the caller fetch_latest_measurements).

    readings: dict[str, float] = {}
    for sensor_id, cpcb_code in sensor_map.items():
        avg = _fetch_sensor_average(api_key, sensor_id, cpcb_code, now_utc)
        if avg is not None:
            # If multiple sensors measure the same pollutant at this location,
            # keep the mean of their averages (rare but possible).
            if cpcb_code in readings:
                readings[cpcb_code] = (readings[cpcb_code] + avg) / 2
            else:
                readings[cpcb_code] = avg

    return location_id, readings


def _fetch_one_location_latest(
    api_key: str,
    location_id: int,
    sensor_map: dict[int, str],
) -> tuple[int, dict]:
    """
    Fallback: fetch the single most-recent reading per sensor at one location.

    Used only when the hourly-average endpoint returns insufficient data
    (e.g. a brand-new station with < 12 hours of history).

    NOTE: Values returned here are NOT averaged over the CPCB window.
    The resulting AQI will be labelled as 'instantaneous' in the UI
    to signal it may differ from CPCB's official 24-hour-average AQI.

    Returns (location_id, {cpcb_code: value}) or (location_id, {}) on failure.
    """
    url = f"{OPENAQ_BASE_URL}/locations/{location_id}/latest"
    try:
        resp = requests.get(
            url,
            headers=_build_headers(api_key),
            params={"limit": 100},
            timeout=OPENAQ_TIMEOUT_S,
        )
        resp.raise_for_status()
        results = resp.json().get("results", [])
    except Exception:
        return location_id, {}

    readings: dict[str, float] = {}
    for record in results:
        sensor_id = record.get("sensorsId")
        raw_value = record.get("value")
        if sensor_id is None or raw_value is None:
            continue
        cpcb_code = sensor_map.get(sensor_id)
        if cpcb_code is None:
            continue
        try:
            value = float(raw_value)
        except (TypeError, ValueError):
            continue
        if not math.isnan(value) and value >= 0:
            readings[cpcb_code] = value

    return location_id, readings


def fetch_latest_measurements(
    api_key: str,
    locations: list[dict],
    sensor_map: dict[int, str],
    location_sensor_map: dict[int, dict[int, str]],
) -> tuple[dict, dict]:
    """
    Fetch CPCB-correct time-averaged concentrations for all locations in parallel.

    Primary path  — CPCB-averaged:
      For each location, calls /sensors/{id}/hours for each of its sensors
      and averages over the CPCB-mandated window (24h PM, 8h CO, 1h NO2/SO2).
      This produces AQI values that match official CPCB published readings.

    Fallback path — instantaneous /latest:
      If a location returns no averaged data (new station, data gap, API error),
      falls back to /locations/{id}/latest for a best-effort snapshot reading.
      These are flagged in the returned dict so the UI can display a warning.

    Uses ThreadPoolExecutor (max 10 workers) for parallel fetching.

    Returns
    -------
    all_readings   : {location_id: {cpcb_code: averaged_concentration}}
    fallback_ids   : set of location_ids that used the /latest fallback
    """
    if not locations:
        return {}, set()

    now_utc     = datetime.now(timezone.utc)
    all_readings: dict     = {}
    fallback_ids: set[int] = set()

    # ── Primary: fetch time-averaged readings ──────────────────────────────────
    # Each location only queries its own sensors (location_sensor_map)
    # so we avoid cross-location spurious API calls.
    def _fetch_averaged(loc: dict) -> tuple[int, dict]:
        loc_id      = loc["id"]
        loc_sensors = location_sensor_map.get(loc_id, {})
        if not loc_sensors:
            return loc_id, {}
        _, readings = _fetch_one_location_averaged(
            api_key, loc_id, loc_sensors, now_utc
        )
        return loc_id, readings

    max_workers = min(10, len(locations))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(_fetch_averaged, loc): loc["id"] for loc in locations}
        for future in as_completed(futures):
            try:
                loc_id, readings = future.result()
                if readings:
                    all_readings[loc_id] = readings
            except Exception:
                pass

    # ── Fallback: /latest for locations with no averaged data ─────────────────
    missing_ids = [
        loc["id"] for loc in locations
        if loc["id"] not in all_readings
    ]

    if missing_ids:
        with ThreadPoolExecutor(max_workers=min(10, len(missing_ids))) as executor:
            futures = {
                executor.submit(
                    _fetch_one_location_latest, api_key, loc_id, sensor_map
                ): loc_id
                for loc_id in missing_ids
            }
            for future in as_completed(futures):
                try:
                    loc_id, readings = future.result()
                    if readings:
                        all_readings[loc_id] = readings
                        fallback_ids.add(loc_id)
                except Exception:
                    pass

    return all_readings, fallback_ids


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def fetch_live_aqi(api_key: str) -> tuple[pd.DataFrame, int, datetime, int]:
    """
    Fetch CPCB-correct AQI for all Mumbai monitoring stations.

    Workflow:
      1. GET /v3/locations?bbox=...  → station list + sensor maps
      2. For each station, fetch time-averaged concentrations:
           PM2.5, PM10 → 24-hour avg via /sensors/{id}/hours
           CO          →  8-hour avg via /sensors/{id}/hours
           NO2, SO2    →  1-hour avg via /sensors/{id}/hours
      3. Fall back to /latest for stations with no hourly history
      4. Compute CPCB AQI = max(sub-indices) per station
      5. Return tidy DataFrame

    Returns
    -------
    df              : DataFrame(station_id, station_name, lat, lon, aqi,
                                pollutants, fetched_at, used_fallback)
    valid_count     : number of stations with a computable AQI
    fetched_at      : UTC timestamp of the fetch
    n_fallback      : number of stations that fell back to instantaneous /latest
    """
    # Step 1: locations + sensor maps
    locations, sensor_map, location_sensor_map = fetch_mumbai_locations(api_key)
    if not locations:
        raise RuntimeError("No active OpenAQ stations found in Mumbai bbox.")

    # Step 2 & 3: averaged readings with /latest fallback
    measurements, fallback_ids = fetch_latest_measurements(
        api_key, locations, sensor_map, location_sensor_map
    )

    # Step 4: build rows
    rows = []
    fetched_at = datetime.now(timezone.utc)

    for loc in locations:
        loc_id = loc["id"]
        coords = loc.get("coordinates", {})
        lat    = coords.get("latitude")
        lon    = coords.get("longitude")
        if lat is None or lon is None:
            continue

        pollutants    = sanitize_pollutant_readings(measurements.get(loc_id, {}))
        aqi_val       = compute_station_aqi(pollutants)
        used_fallback = loc_id in fallback_ids

        rows.append({
            "station_id":    loc_id,
            "station_name":  loc.get("name", f"Station {loc_id}"),
            "lat":           float(lat),
            "lon":           float(lon),
            "aqi":           aqi_val if aqi_val is not None else float("nan"),
            "pollutants":    pollutants,
            "fetched_at":    fetched_at,
            # True = AQI computed from instantaneous /latest (not CPCB-averaged)
            # False = AQI computed from proper time-averaged concentrations
            "used_fallback": used_fallback,
        })

    df          = pd.DataFrame(rows)
    valid_count = int(df["aqi"].notna().sum())
    n_fallback  = int(df["used_fallback"].sum()) if "used_fallback" in df.columns else 0

    return df, valid_count, fetched_at, n_fallback


# ══════════════════════════════════════════════════════════════════════════════
# HISTORICAL FALLBACK
# ══════════════════════════════════════════════════════════════════════════════

def load_historical_surface(now: Optional[datetime] = None) -> pd.DataFrame:
    """
    Load historical road AQI surface matching the current time slot.
    Used when live data is unavailable or insufficient.
    """
    if now is None:
        now = datetime.now()

    try:
        df = pd.read_csv(FALLBACK_CSV_PATH, parse_dates=["datetime"])
        df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
    except FileNotFoundError:
        raise FileNotFoundError(
            f"Historical fallback file not found at '{FALLBACK_CSV_PATH}'. "
            "Run Interpolation_Road_AQI.ipynb first."
        )

    df["hour"]       = df["datetime"].dt.hour
    df["month"]      = df["datetime"].dt.month
    df["is_weekend"] = (df["datetime"].dt.dayofweek >= 5).astype(int)

    data_month = HISTORICAL_MONTH_MAP[now.month]
    hour       = now.hour
    is_weekend = int(now.weekday() >= 5)

    for query in [
        (df["month"] == data_month) & (df["hour"] == hour) & (df["is_weekend"] == is_weekend),
        (df["month"] == data_month) & (df["hour"] == hour),
        (df["month"] == data_month),
    ]:
        sl = df[query][["edge_idx", "mid_lat", "mid_lon", "aqi_pred"]]
        if len(sl) > 0:
            return (
                sl.groupby("edge_idx")
                .agg({"mid_lat": "first", "mid_lon": "first", "aqi_pred": "mean"})
                .reset_index()
            )

    return (
        df[["edge_idx", "mid_lat", "mid_lon", "aqi_pred"]]
        .groupby("edge_idx")
        .agg({"mid_lat": "first", "mid_lon": "first", "aqi_pred": "mean"})
        .reset_index()
    )


def should_refresh_cache(last_fetch: Optional[datetime]) -> bool:
    """Return True if cache is older than CACHE_TTL_MINUTES or never set."""
    if last_fetch is None:
        return True
    age = datetime.now(timezone.utc) - last_fetch.replace(tzinfo=timezone.utc)
    return age > timedelta(minutes=CACHE_TTL_MINUTES)
