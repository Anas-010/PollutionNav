"""
modules/map_builder.py
======================
Builds all Folium maps displayed in the Streamlit app.

Three map types:
  1. empty_map()      — shown before any route is requested (station overview)
  2. route_map()      — shown after routing, with AQI surface + route polylines
  3. surface_only()   — shows just the AQI pollution raster without routes

Design decisions:
  - CartoDB Positron tile layer — muted grey background so the AQI colours
    stand out clearly without visual noise.
  - AQI road surface rendered as CircleMarkers (one per road segment midpoint)
    rather than as a raster image, because Folium handles vector markers more
    reliably across zoom levels than image overlays.
  - Sampled to ≤8,000 markers for browser rendering performance. The full
    dataset has ~50,000 segments which causes lag in lower-end browsers.
  - Route polylines drawn in official CPCB colours — blue for fastest,
    green for cleanest — so the legend is self-consistent with the AQI surface.
"""

import math

import folium
import pandas as pd
import numpy as np

from config import AQI_PALETTE, AQI_EMOJI, AQI_CATEGORIES, MUMBAI_CENTER


# ══════════════════════════════════════════════════════════════════════════════
# AQI HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def aqi_category(value) -> str:
    """Map a numeric AQI value to its CPCB category name."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "Unknown"
    for threshold, name in AQI_CATEGORIES:
        if value <= threshold:
            return name
    return "Severe"


def aqi_color(value) -> str:
    """Map a numeric AQI value to its CPCB colour hex string."""
    return AQI_PALETTE.get(aqi_category(value), "#aaaaaa")


# ══════════════════════════════════════════════════════════════════════════════
# MAP COMPONENTS
# ══════════════════════════════════════════════════════════════════════════════

def _base_map(center=None, zoom=12) -> folium.Map:
    """Create a base Folium map with CartoDB Positron tiles."""
    return folium.Map(
        location=center or MUMBAI_CENTER,
        zoom_start=zoom,
        tiles="CartoDB positron",
        control_scale=True,
    )


def _add_aqi_road_layer(m: folium.Map, road_aqi_df: pd.DataFrame,
                         sample_n: int = 8000) -> folium.Map:
    """
    Add AQI-coloured dots at road segment midpoints as a FeatureGroup layer.

    Each dot represents one road segment. Colour follows the CPCB AQI palette.
    The layer is togglable via the LayerControl.

    Sampling: we cap at sample_n dots for browser performance. Road segments
    are sampled uniformly so the spatial coverage is preserved.
    """
    valid = road_aqi_df.dropna(subset=["mid_lat", "mid_lon", "aqi_pred"])
    if len(valid) > sample_n:
        valid = valid.sample(sample_n, random_state=42)

    aqi_fg = folium.FeatureGroup(name="AQI Road Surface", show=True)
    for _, row in valid.iterrows():
        folium.CircleMarker(
            location=[row["mid_lat"], row["mid_lon"]],
            radius=2,
            color=aqi_color(row["aqi_pred"]),
            fill=True,
            fill_opacity=0.55,
            weight=0,
            tooltip=(
                f"AQI: {row['aqi_pred']:.0f} "
                f"({aqi_category(row['aqi_pred'])})"
            ),
        ).add_to(aqi_fg)
    aqi_fg.add_to(m)
    return m


def _add_station_markers(m: folium.Map, stations_df: pd.DataFrame,
                          show_aqi: bool = True) -> folium.Map:
    """
    Add monitoring station markers. Coloured by live AQI if available.

    Parameters
    ----------
    show_aqi : if True, colour each marker by its AQI value;
               if False, use a neutral blue (no AQI data loaded yet)
    """
    stn_fg = folium.FeatureGroup(name="Monitoring Stations", show=True)

    for _, row in stations_df.iterrows():
        lat = row.get("lat")
        lon = row.get("lon")
        if lat is None or lon is None:
            continue

        aqi_val  = row.get("aqi", float("nan"))
        name     = str(row.get("station_name", "Station")).split(",")[0]

        if show_aqi and not (isinstance(aqi_val, float) and math.isnan(aqi_val)):
            color   = aqi_color(aqi_val)
            tooltip = (f"{name}<br>AQI: {aqi_val:.0f} "
                       f"({aqi_category(aqi_val)})")
            radius  = 8
        else:
            color   = "#1a73e8"
            tooltip = name
            radius  = 6

        folium.CircleMarker(
            location=[lat, lon],
            radius=radius,
            color="white",
            fill=True,
            fill_color=color,
            fill_opacity=0.9,
            weight=2,
            tooltip=tooltip,
        ).add_to(stn_fg)

    stn_fg.add_to(m)
    return m


def _add_route_lines(m: folium.Map, routes: list[dict],
                      selected_idx: int = None) -> folium.Map:
    """
    Draw route polylines on the map.

    Visual encoding:
      Fastest route  → solid blue (#1a73e8)
      Cleanest route → solid green (#2ecc71)
      Others         → dashed grey
      Selected route → thicker line weight

    Each route has a tooltip showing its label, travel time, and mean AQI.
    """
    fastest_idx  = next((i for i, r in enumerate(routes) if r.get("is_fastest")),  0)
    cleanest_idx = next((i for i, r in enumerate(routes) if r.get("is_cleanest")), 0)

    for i, route in enumerate(routes):
        coords_ll = [[lat, lon] for lon, lat in route["geometry"]]

        same = (i == fastest_idx == cleanest_idx)

        if same:
            color, weight, dash, label = "#1a73e8", 7, None, "Fastest & Cleanest"
        elif i == fastest_idx:
            color, weight, dash, label = "#1a73e8", 6, None, "Fastest"
        elif i == cleanest_idx:
            color, weight, dash, label = "#2ecc71", 6, None, "Cleanest"
        else:
            color, weight, dash, label = "#888888", 3, "5 5", f"Route {i + 1}"

        # Bold line for the currently selected route
        if selected_idx is not None and i == selected_idx:
            weight += 3

        mean_aqi = route.get("mean_aqi", float("nan"))
        aqi_str  = (f"{mean_aqi:.0f} ({aqi_category(mean_aqi)})"
                    if not math.isnan(mean_aqi) else "AQI N/A")

        tooltip = (f"<b>{label}</b><br>"
                   f"⏱ {route.get('duration_str', '—')}<br>"
                   f"📏 {route.get('distance_str', '—')}<br>"
                   f"🌫️ {aqi_str}")

        kw = dict(
            locations=coords_ll,
            color=color,
            weight=weight,
            opacity=0.88,
            tooltip=folium.Tooltip(tooltip),
        )
        if dash:
            kw["dash_array"] = dash

        folium.PolyLine(**kw).add_to(m)

    return m


def _add_origin_dest_markers(
    m: folium.Map,
    origin_ll: tuple[float, float],
    dest_ll: tuple[float, float],
    origin_label: str = "Origin",
    dest_label: str = "Destination",
) -> folium.Map:
    """Add origin (green play button) and destination (red flag) markers."""
    folium.Marker(
        location=list(origin_ll),
        tooltip=f"<b>Start:</b> {origin_label}",
        icon=folium.Icon(color="green", icon="play", prefix="fa"),
    ).add_to(m)

    folium.Marker(
        location=list(dest_ll),
        tooltip=f"<b>End:</b> {dest_label}",
        icon=folium.Icon(color="red", icon="flag", prefix="fa"),
    ).add_to(m)
    return m


def _add_legend(m: folium.Map, show_route_legend: bool = False) -> folium.Map:
    """
    Inject a fixed-position HTML legend into the map.

    Shows the CPCB AQI colour scale. Optionally shows route line colours.
    """
    route_legend = ""
    if show_route_legend:
        route_legend = """
        <br><b>Routes:</b><br>
        <span style="color:#1a73e8;font-size:18px">━━</span>&nbsp;Fastest<br>
        <span style="color:#2ecc71;font-size:18px">━━</span>&nbsp;Cleanest<br>
        <span style="color:#888;font-size:14px">╌╌</span>&nbsp;Alternative
        """

    legend_html = f"""
    <div style="
        position: fixed;
        bottom: 30px; left: 30px;
        z-index: 1000;
        background: white;
        padding: 12px 16px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        font-size: 12px;
        font-family: sans-serif;
        line-height: 1.8;
    ">
        <b style="font-size:13px">CPCB AQI Scale</b><br>
        <span style="color:#00c400">●</span>&nbsp;Good (0–50)<br>
        <span style="color:#92d14f">●</span>&nbsp;Satisfactory (51–100)<br>
        <span style="color:#e0c800">●</span>&nbsp;Moderate (101–200)<br>
        <span style="color:#ff7e00">●</span>&nbsp;Poor (201–300)<br>
        <span style="color:#e00000">●</span>&nbsp;Very Poor (301–400)<br>
        <span style="color:#7e0023">●</span>&nbsp;Severe (401+)
        {route_legend}
    </div>"""

    m.get_root().html.add_child(folium.Element(legend_html))
    return m


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC MAP BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def empty_map(stations_df: pd.DataFrame = None,
              show_aqi: bool = False) -> folium.Map:
    """
    Build the initial overview map shown before any route is requested.

    Displays monitoring station locations (coloured by live AQI if available,
    neutral blue otherwise). Gives the user a sense of the data coverage.
    """
    m = _base_map()
    if stations_df is not None and len(stations_df) > 0:
        m = _add_station_markers(m, stations_df, show_aqi=show_aqi)
    m = _add_legend(m)
    folium.LayerControl().add_to(m)
    return m


def route_map(
    origin_ll: tuple[float, float],
    dest_ll: tuple[float, float],
    routes: list[dict],
    road_aqi_df: pd.DataFrame = None,
    stations_df: pd.DataFrame = None,
    selected_idx: int = None,
    origin_label: str = "Origin",
    dest_label: str = "Destination",
) -> folium.Map:
    """
    Build the full route map shown after routing.

    Layers (bottom to top):
      1. CartoDB Positron base tiles
      2. AQI road surface (coloured dots at road midpoints)
      3. Monitoring station markers
      4. Route polylines (fastest=blue, cleanest=green, others=grey)
      5. Origin and destination markers
      6. AQI + route legend

    Parameters
    ----------
    origin_ll    : (lat, lon) of origin
    dest_ll      : (lat, lon) of destination
    routes       : list of route dicts from routing.fetch_routes()
    road_aqi_df  : DataFrame(edge_idx, mid_lat, mid_lon, aqi_pred) — the surface
    stations_df  : DataFrame(lat, lon, station_name, aqi) — for station markers
    selected_idx : index of the currently selected route (gets bold line)
    origin_label : display name of origin
    dest_label   : display name of destination
    """
    center = [
        (origin_ll[0] + dest_ll[0]) / 2,
        (origin_ll[1] + dest_ll[1]) / 2,
    ]
    m = _base_map(center=center, zoom=13)

    # Layer 1: AQI road surface
    if road_aqi_df is not None and len(road_aqi_df) > 0:
        m = _add_aqi_road_layer(m, road_aqi_df)

    # Layer 2: Monitoring station markers
    if stations_df is not None and len(stations_df) > 0:
        m = _add_station_markers(
            m, stations_df,
            show_aqi=not stations_df["aqi"].isna().all()
        )

    # Layer 3: Route polylines
    if routes:
        m = _add_route_lines(m, routes, selected_idx=selected_idx)

    # Layer 4: Origin / destination pins
    m = _add_origin_dest_markers(m, origin_ll, dest_ll, origin_label, dest_label)

    # Legend
    m = _add_legend(m, show_route_legend=bool(routes))

    folium.LayerControl().add_to(m)
    return m


def surface_only_map(
    road_aqi_df: pd.DataFrame,
    stations_df: pd.DataFrame = None,
    data_label: str = "",
) -> folium.Map:
    """
    Show just the AQI pollution surface without any route.

    Used in the 'AQI Surface' tab to let users explore the current
    pollution map before deciding where to travel.
    """
    m = _base_map()
    m = _add_aqi_road_layer(m, road_aqi_df, sample_n=12000)

    if stations_df is not None and len(stations_df) > 0:
        m = _add_station_markers(
            m, stations_df,
            show_aqi=not stations_df["aqi"].isna().all()
        )

    # Add data source label to the legend
    label_html = f"""
    <div style="
        position: fixed; top: 10px; right: 10px; z-index: 1000;
        background: white; padding: 8px 12px; border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.18); font-size: 11px;
        font-family: sans-serif; color: #444;
    ">
        {data_label}
    </div>"""
    m.get_root().html.add_child(folium.Element(label_html))

    m = _add_legend(m)
    folium.LayerControl().add_to(m)
    return m
