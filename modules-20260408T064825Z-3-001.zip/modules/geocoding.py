"""
modules/geocoding.py
====================
Converts user-typed location strings to geographic coordinates (lat, lon).

Uses Nominatim (OpenStreetMap's geocoding service) — free and does not
require an API key, but has a usage policy of 1 request per second maximum.

Mumbai bias:
  We append ", Mumbai, India" to the query before trying a global search.
  This dramatically improves accuracy for local landmark names (e.g.
  "Bandra Station" → finds the correct Bandra railway station in Mumbai
  rather than a similarly named place elsewhere in India).

Caching:
  Results are cached in-process using a simple dict. The same address
  query within a session will not re-hit the Nominatim API.
  This is important because Streamlit re-runs the entire script on
  every UI interaction and we do not want to re-geocode on every rerun.
"""

from functools import lru_cache
from typing import Optional, Tuple

from geopy.exc import GeocoderTimedOut, GeocoderServiceError
from geopy.geocoders import Nominatim

from config import MUMBAI_BBOX

# Nominatim viewbox for Mumbai — biases results toward this area.
# Format expected by geopy: [(sw_lat, sw_lon), (ne_lat, ne_lon)]
_MUMBAI_VIEWBOX = [
    (MUMBAI_BBOX["south"], MUMBAI_BBOX["west"]),
    (MUMBAI_BBOX["north"], MUMBAI_BBOX["east"]),
]

# Single shared geolocator instance — Nominatim requires a descriptive
# user_agent string to identify your application.
_geolocator = Nominatim(user_agent="mumbai_aqi_route_planner_v2")


@lru_cache(maxsize=256)
def geocode(address: str) -> Optional[Tuple[float, float]]:
    """
    Convert an address string to (latitude, longitude).

    Strategy:
      1. Try "address, Mumbai, India" with viewbox bias
         → best for Mumbai-specific landmarks and neighbourhoods
      2. Try "address, Mumbai, India" without viewbox constraint
         → catches cases where the correct result is just outside the viewbox
      3. Try raw address globally
         → last resort for unrecognised inputs

    Parameters
    ----------
    address : free-text location string entered by the user

    Returns
    -------
    (lat, lon) tuple if successful, or None if all attempts fail.

    Notes
    -----
    The @lru_cache decorator caches results by the exact address string.
    The same query within a Python process will not re-call the API.
    """
    queries = [
        # Attempt 1: Mumbai-biased search with viewbox
        (f"{address}, Mumbai, India", True),
        # Attempt 2: Mumbai-biased without viewbox restriction
        (f"{address}, Mumbai, India", False),
        # Attempt 3: global fallback
        (address, False),
    ]

    for query_str, use_viewbox in queries:
        try:
            kwargs = {"timeout": 10}
            if use_viewbox:
                kwargs["viewbox"]  = _MUMBAI_VIEWBOX
                kwargs["bounded"]  = False   # Return best match even outside viewbox

            loc = _geolocator.geocode(query_str, **kwargs)
            if loc:
                return float(loc.latitude), float(loc.longitude)

        except GeocoderTimedOut:
            continue   # Try next query strategy
        except GeocoderServiceError:
            continue

    return None   # All strategies exhausted


def reverse_geocode(lat: float, lon: float) -> str:
    """
    Convert a coordinate to a human-readable address string.

    Used to display the resolved location back to the user so they can
    confirm the geocoder found the right place.

    Returns a short address string, or "Unknown location" on failure.
    """
    try:
        loc = _geolocator.reverse((lat, lon), timeout=10, language="en")
        if loc:
            # Extract the most meaningful parts of the address
            addr = loc.raw.get("address", {})
            parts = [
                addr.get("road"),
                addr.get("suburb") or addr.get("neighbourhood"),
                addr.get("city_district") or addr.get("borough"),
            ]
            return ", ".join(p for p in parts if p) or loc.address.split(",")[0]
    except Exception:
        pass
    return "Unknown location"
